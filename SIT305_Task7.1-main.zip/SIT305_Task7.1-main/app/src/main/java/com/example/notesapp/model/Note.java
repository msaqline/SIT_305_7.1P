package com.example.notesapp.model;

public class Note {
    private int id;
    private String name, content;
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public Note(String name, String content) {
        this.name = name;
        this.content = content;
    }


}
